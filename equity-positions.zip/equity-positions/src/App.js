import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import InputTab from './components/InputTab';
import OutputTab from './components/OutputTab';
import AllTradeTab from './components/AllTradeTab';
import './App.css'; // Import the CSS file

function App() {
  return (
    <Router>
      <div className="app-container">
        <nav className="navbar">
          <Link to="/" className="nav-link">Input</Link>
          <Link to="/output" className="nav-link">Net Positions</Link>
          <Link to="/trades" className="nav-link">All Trades</Link>
        </nav>
        <div className="content">
          <Routes>
            <Route path="/" element={<InputTab />} />
            <Route path="/output" element={<OutputTab />} />
            <Route path="/trades" element={<AllTradeTab />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;