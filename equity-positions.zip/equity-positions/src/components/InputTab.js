import React, { useState } from 'react';
import { sendTransaction } from '../services/api';

function InputTab() {
  const [form, setForm] = useState({
    tradeId: '',
    version: '',
    securityCode: '',
    quantity: '',
    action: 'INSERT',
    direction: 'Buy',
  });

  const [errors, setErrors] = useState({});

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: '' }); // Clear error on change
  };

  const validateForm = () => {
    const newErrors = {};
    if (!/^\d+$/.test(form.tradeId)) newErrors.tradeId = 'Trade ID must be an integer';
    if (!/^\d+$/.test(form.version)) newErrors.version = 'Version must be an integer';
    if (!/^\d+$/.test(form.quantity)) newErrors.quantity = 'Quantity must be an integer';
    return newErrors;
  };

  const handleSubmit = async e => {
    e.preventDefault();
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    await sendTransaction(form);
    alert('Transaction submitted!');
  };

  const formStyle = {
    maxWidth: '500px',
    margin: '2rem auto',
    padding: '2rem',
    border: '1px solid #ccc',
    borderRadius: '8px',
    backgroundColor: '#f9f9f9',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
    fontFamily: 'Arial, sans-serif',
  };

  const inputStyle = {
    width: '100%',
    padding: '10px',
    marginBottom: '5px',
    borderRadius: '4px',
    border: '1px solid #ccc',
    fontSize: '1rem',
  };

  const errorStyle = {
    color: 'red',
    fontSize: '0.9rem',
    marginBottom: '10px',
  };

  const selectStyle = { ...inputStyle };

  const buttonStyle = {
    width: '100%',
    padding: '12px',
    backgroundColor: '#007bff',
    color: '#fff',
    border: 'none',
    borderRadius: '4px',
    fontSize: '1rem',
    cursor: 'pointer',
    marginTop: '10px',
  };

  const buttonHoverStyle = {
    backgroundColor: '#0056b3',
  };

  return (
    <form onSubmit={handleSubmit} style={formStyle}>
      <h2 style={{ textAlign: 'center', marginBottom: '1rem' }}>Submit Trade</h2>

      <input
        name="tradeId"
        type="number"
        placeholder="Trade ID"
        onChange={handleChange}
        style={inputStyle}
        value={form.tradeId}
      />
      {errors.tradeId && <div style={errorStyle}>{errors.tradeId}</div>}

      <input
        name="version"
        type="number"
        placeholder="Version"
        onChange={handleChange}
        style={inputStyle}
        value={form.version}
      />
      {errors.version && <div style={errorStyle}>{errors.version}</div>}

      <input
        name="securityCode"
        placeholder="Security Code"
        onChange={handleChange}
        style={inputStyle}
        value={form.securityCode}
      />

      <input
        name="quantity"
        type="number"
        placeholder="Quantity"
        onChange={handleChange}
        style={inputStyle}
        value={form.quantity}
      />
      {errors.quantity && <div style={errorStyle}>{errors.quantity}</div>}

      <select name="action" onChange={handleChange} style={selectStyle} value={form.action}>
        <option>INSERT</option>
        <option>UPDATE</option>
        <option>CANCEL</option>
      </select>

      <select name="direction" onChange={handleChange} style={selectStyle} value={form.direction}>
        <option>Buy</option>
        <option>Sell</option>
      </select>

      <button
        type="submit"
        style={buttonStyle}
        onMouseOver={e => (e.target.style.backgroundColor = buttonHoverStyle.backgroundColor)}
        onMouseOut={e => (e.target.style.backgroundColor = buttonStyle.backgroundColor)}
      >
        Submit
      </button>
    </form>
  );
}

export default InputTab;
