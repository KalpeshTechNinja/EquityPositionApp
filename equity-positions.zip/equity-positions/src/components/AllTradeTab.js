import React, { useEffect, useState } from 'react';
import { getAllTrades } from '../services/api';

function AllTradeTab() {
  const [trades, setPositions] = useState({});

  useEffect(() => {
    getAllTrades().then(setPositions);
  }, []);

  return (
    <div>
      <h2>All Trades</h2>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <th>Transaction ID</th>
            <th>Trade ID</th>
            <th>Version</th>
            <th>Security Code</th>
            <th>Quantity</th>
            <th>Action</th>
            <th>Direction</th>
          </tr>
        </thead>
        <tbody>
          {Object.entries(trades).map(([transactionId, trade]) => (
            <tr key={transactionId}>
              <td>{transactionId}</td>
              <td>{trade.tradeId}</td>
              <td>{trade.version}</td>
              <td>{trade.securityCode}</td>
              <td>{trade.quantity}</td>
              <td>{trade.action}</td>
              <td>{trade.direction}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default AllTradeTab;
