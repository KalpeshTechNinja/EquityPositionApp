import React, { useEffect, useState } from 'react';
import { getPositions } from '../services/api';

function OutputTab() {
  const [positions, setPositions] = useState({});

  useEffect(() => {
    getPositions().then(setPositions);
  }, []);

  const containerStyle = {
    maxWidth: '600px',
    margin: '2rem auto',
    padding: '2rem',
    border: '1px solid #ddd',
    borderRadius: '8px',
    backgroundColor: '#fefefe',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
    fontFamily: 'Segoe UI, sans-serif',
  };

  const headingStyle = {
    textAlign: 'center',
    marginBottom: '1.5rem',
    fontSize: '1.5rem',
    color: '#333',
  };

  const listStyle = {
    listStyleType: 'none',
    padding: 0,
    margin: 0,
  };

  const itemStyle = {
    padding: '10px 15px',
    marginBottom: '10px',
    borderRadius: '6px',
    backgroundColor: '#f0f4f8',
    border: '1px solid #ccc',
    fontSize: '1rem',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  };

  const codeStyle = {
    fontWeight: 'bold',
    color: '#007bff',
  };

  const valueStyle = {
    color: '#333',
  };

 return (
  <div style={containerStyle}>
    <h2 style={headingStyle}>Net Positions</h2>
    <ul style={listStyle}>
      {Object.entries(positions).map(([code, value]) => {
        const formattedValue = value >= 0 ? `+${value}` : `-${Math.abs(value)}`;
        return (
          <li key={code} style={itemStyle}>
            <span style={codeStyle}>{code}</span>
            <span style={valueStyle}>{formattedValue}</span>
          </li>
        );
      })}
    </ul>
  </div>
);

}

export default OutputTab;
