import axios from 'axios';

const API_URL = 'http://localhost:5152';

// export const sendTransaction = async (data) => {
//   await axios.post(`${API_URL}/transaction`, data);
// };

export const sendTransaction = async (data) => {
  try {
    console.log(data);
    await axios.post(`${API_URL}/Transaction`, data);
     console.log('Record Inserted.');
  } catch (error) {
    console.error('Axios Network Error:', error.message);
  }
};


export const getPositions = async (data) => {
  try {
     const res = await axios.get(`${API_URL}/Transaction/positions`);
     console.log(res);
     return res.data;
  } catch (error) {
    console.error('Axios Network Error:', error.message);
  }
};

// export const getPositions = async () => {
//   const res = await axios.get(`${API_URL}/positions`);
//   return res.data;
// };

// export const getAllTrades = async () => {
//   const res = await axios.get(`${API_URL}/trades`);
//   return res.data;
// };


export const getAllTrades = async (data) => {
  try {
     const res = await axios.get(`${API_URL}/Transaction/trades`);
      console.log(res);
     return res.data;
  } catch (error) {
    console.error('Axios Network Error:', error.message);
  }
};