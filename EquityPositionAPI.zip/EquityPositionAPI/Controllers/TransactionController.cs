using Microsoft.AspNetCore.Mvc;
using EquityPositionAPI.Models;
using EquityPositionAPI.Services;
using System.Web.Http.Cors;


namespace EquityPositionAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [EnableCors(origins: "http://localhost:3000", headers: "*", methods: "*")]
    public class TransactionController : ControllerBase
    {
        private readonly TradeService _tradeService;

        public TransactionController(TradeService tradeService)
        {
            _tradeService = tradeService;
        }
        
        [HttpPost]
        public async Task<IActionResult> PostTransaction([FromBody] Transaction transaction)
        {
            await _tradeService.AddTransactionAsync(transaction);
            return Ok();
        }

        [HttpGet("positions")]
        public async Task<IActionResult> GetPositions()
        {
            var positions = await _tradeService.GetNetPositionsAsync();
            return Ok(positions);
        }

        [HttpGet("trades")]
        public async Task<IActionResult> GetallTrades()
        {
            var allTrades = await _tradeService.GetallTrades();
            return Ok(allTrades);
        }
    }
}