using EquityPositionAPI.Data;
using EquityPositionAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace EquityPositionAPI.Services
{
    public class TradeService
    {
        private readonly AppDbContext _context;

        public TradeService(AppDbContext context)
        {
            _context = context;
        }

        public async Task AddTransactionAsync(Transaction transaction)
        {
            _context.Transactions.Add(transaction);
            await _context.SaveChangesAsync();
        }

        public async Task<Dictionary<string, int>> GetNetPositionsAsync()
        {
            var trades = await _context.Transactions.ToListAsync(); // Materialize first

            var latestTrades = trades
                .GroupBy(t => t.TradeId)
                .Select(g => g.OrderByDescending(t => t.Version).First())
                .Where(t => t.Action != "CANCEL");

            var positions = new Dictionary<string, int>();

            foreach (var trade in latestTrades)
            {
         
                int sign = trade.Direction == "Buy" ? 1 : -1;
                int qty = sign * trade.Quantity;

                if (!positions.ContainsKey(trade.SecurityCode))
                    positions[trade.SecurityCode] = 0;

                positions[trade.SecurityCode] += qty;
            }

            //Aslo trades which got cancelled in latest version, consdier second previous version and show net postion of it.
            var scriptWithCancelTrades = trades
                .GroupBy(t => t.TradeId)
                .Select(g => g.OrderByDescending(t => t.Version).First())
                .Where(t => t.Action == "CANCEL").Select(y => y.SecurityCode);

            foreach(var scr in scriptWithCancelTrades)
            {
                var remainingtrades = trades.Where(x => x.SecurityCode == scr && x.Action != "CANCEL");

                foreach (var trade in remainingtrades)
                {
                    int sign = trade.Direction == "Buy" ? 1 : -1;
                    int qty = sign * trade.Quantity;

                    if (!positions.ContainsKey(trade.SecurityCode))
                        positions[trade.SecurityCode] = 0;

                    positions[trade.SecurityCode] += qty > 0 ? qty : 0;
                }

            }

            return positions;
        }


        public async Task<List<Transaction>> GetallTrades()
        {
            return await _context.Transactions.ToListAsync();
        }
    }
}
